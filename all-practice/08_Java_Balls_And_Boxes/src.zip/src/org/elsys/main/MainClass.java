package org.elsys.main;
import java.util.Scanner;

public class MainClass {
	Scanner sc = new Scanner(System.in);
    

}
