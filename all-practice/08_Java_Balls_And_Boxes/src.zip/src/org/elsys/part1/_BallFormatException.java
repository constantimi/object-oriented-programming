package org.elsys.part1;

public class _BallFormatException extends Exception {

}
