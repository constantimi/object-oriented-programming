package org.elsys.part1;

import java.util.ArrayList;
import java.util.List;

public class BallContainer {

	public BallContainer() {
	}

	List <Ball> balls = new ArrayList<Ball>();
	
	/** 
	 * Adds a ball to the container.
	 * @param b the Ball to be added
	 * @return true if b was successfully added
	 */
	public boolean add(Ball b) {
		try {
			balls.add(b);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/**
	 * Removes a ball from the container.
	 * @param b the Ball to be removed
	 * @return true if b was present in the collection
	 */
	public boolean remove(Ball b) {
		try {
			balls.remove(b);
		} catch(Exception e) {
				return false;
		}
		return true;
	}

	/**
	 * Returns the sum of the volumes of all balls in the container.
	 * @return
	 */
	public double getVolume() {
		double sum = 0.0;
		return sum;
	}

	/**
	 * Returns the total count of balls in the container.
	 * @return
	 */
	public int size() {
		return balls.size();
	}

	/**
	 *  Removes all balls from the container.
	 */
	public void clear() {
		balls.clear();
	}

	/**
	 * Checks whether a Ball is present in the container.
	 * @param b the Ball to check
	 * @return true if b is present
	 */
	public boolean contains(Ball b) {
		try {
			
		} catch (Exception e) {
			return true;
		}
		return false;
	}
	
	

}