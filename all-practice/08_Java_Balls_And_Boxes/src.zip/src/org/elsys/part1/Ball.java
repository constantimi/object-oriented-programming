
package org.elsys.part1;

public class Ball {
	public double volume;
	public Color color;

	public Ball(double volume, Color color) {
		this.volume = volume;
		this.color = color;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
	public Ball(double volume) {
		this.volume = volume;
	}

}