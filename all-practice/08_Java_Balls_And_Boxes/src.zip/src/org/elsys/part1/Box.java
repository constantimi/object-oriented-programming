package org.elsys.part1;

import java.util.Iterator;

public class Box extends BallContainer {

	public Box(double capacity) {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public Iterator<Ball> getBallsFromSmallest() {
		//list of balls and sort and returns iterator
		//we have to copy container and then
		return null;
	}

}